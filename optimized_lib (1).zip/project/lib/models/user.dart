import 'album.dart';

class InvalidUserNameException implements Exception {
  final String message;
  InvalidUserNameException([this.message = 'Invalid username format']);
  @override
  String toString() => message;
}

class InvalidPasswordException implements Exception {
  final String message;
  InvalidPasswordException([this.message = 'Invalid password']);
  @override
  String toString() => message;
}

class User {
  String _userName;
  String _password;
  final List<Album> _albums = [];
  bool _banned = false;

  User._(this._userName, this._password) {
    _albums.add(Album(name: 'Photos'));
  }

  static User create(String userName, String password) {
    if (!isValidUserName(userName)) throw InvalidUserNameException();
    if (!isValidPassword(password, userName)) throw InvalidPasswordException();
    return User._(userName, password);
  }

  static bool isValidUserName(String userName) {
    final emailRegex = RegExp(r'^[\w\-.]+@([\w-]+\.)+[\w-]{2,4}$');
    final phoneRegex = RegExp(r'^\+?0?9\d{9}$');
    return emailRegex.hasMatch(userName) || phoneRegex.hasMatch(userName);
  }

  static bool isValidPassword(String password, String userName) {
    if (password.length < 8) return false;
    if (password.toLowerCase().contains(userName.toLowerCase())) return false;
    final hasUpper = password.contains(RegExp(r'[A-Z]'));
    final hasLower = password.contains(RegExp(r'[a-z]'));
    final hasDigit = password.contains(RegExp(r'[0-9]'));
    return hasUpper && hasLower && hasDigit;
  }

  String get userName => _userName;
  String get password => _password;
  bool get isBanned => _banned;
  List<Album> get albums => List.unmodifiable(_albums);

  set userName(String newName) => _userName = newName;
  set password(String newPassword) => _password = newPassword;
  set banned(bool value) => _banned = value;

  void addAlbum(Album album) => _albums.add(album);

  void addImageToDefaultAlbum(PhotoItem photo) {
    if (_albums.isNotEmpty) _albums.first.addPhoto(photo);
  }
}
