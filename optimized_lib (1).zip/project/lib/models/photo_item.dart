import 'comment.dart';
import 'album.dart';

class PhotoItem {
  final String name;
  final double size;
  final DateTime date;
  final String? location;
  final String saveAddress;
  final String caption;
  final List<String> objects;
  final List<String> tags;
  final List<Album> albums;
  bool liked;
  final List<Comment> comments;
  bool commentable;

  PhotoItem({
    required this.name,
    required this.saveAddress,
    this.caption = '',
    List<String>? tags,
    List<Album>? albums,
    List<String>? objects,
    this.location,
    this.size = 0,
    this.liked = false,
    this.commentable = true,
  })  : date = DateTime.now(),
        tags = tags ?? [],
        albums = albums ?? [],
        objects = objects ?? [],
        comments = [];

  void addComment(Comment comment) {
    if (commentable) comments.add(comment);
  }

  PhotoItem copyWith({
    String? name,
    bool? liked,
    bool? commentable,
    String? caption,
  }) {
    return PhotoItem(
      name: name ?? this.name,
      saveAddress: saveAddress,
      caption: caption ?? this.caption,
      tags: tags,
      albums: albums,
      objects: objects,
      location: location,
      size: size,
      liked: liked ?? this.liked,
      commentable: commentable ?? this.commentable,
    );
  }
}
