import 'user.dart';

class Admin {
  String userName;
  String password;
  final int adminId;

  Admin({
    required this.userName,
    required this.password,
    required this.adminId,
  });

  int albumCount(User user) => user.albums.length;

  int imagesCount(User user) =>
      user.albums.isNotEmpty ? user.albums.first.count : 0;

  void banUser(User user) => user.banned = true;
  void unbanUser(User user) => user.banned = false;
}
