import 'user.dart';

class Comment {
  final String title;
  final String context;
  final DateTime date;
  final User user;

  Comment({
    required this.user,
    required this.title,
    required this.context,
  }) : date = DateTime.now();
}
