import 'photo_item.dart';

class Album {
  final String name;
  final int? albumId;
  final DateTime date;
  final List<PhotoItem> _photos = [];

  Album({required this.name, this.albumId}) : date = DateTime.now();

  List<PhotoItem> get photos => List.unmodifiable(_photos);
  int get count => _photos.length;

  void addPhoto(PhotoItem photo) => _photos.add(photo);
  void removePhoto(PhotoItem photo) => _photos.remove(photo);
}
